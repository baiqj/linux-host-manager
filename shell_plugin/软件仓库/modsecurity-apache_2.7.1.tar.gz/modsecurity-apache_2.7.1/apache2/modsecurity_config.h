/* This file is left empty for building on Windows. */
